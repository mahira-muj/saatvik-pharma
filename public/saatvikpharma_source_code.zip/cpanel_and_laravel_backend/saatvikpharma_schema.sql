-- ========================================================
-- Saatvik Pharma MySQL Database Schema & Initial Seed Data
-- Compatible with MySQL 5.7+ / 8.0+ & MariaDB 10.3+ in cPanel phpMyAdmin
-- Character Set: utf8mb4, Collation: utf8mb4_unicode_ci
-- ========================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Admins Table
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `role` VARCHAR(30) DEFAULT 'superadmin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_login` DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default Admin: admin@saatvikpharma.com / Saatvik@Admin2026!
-- (Uses standard PHP password_hash compatible bcrypt)
INSERT INTO `admins` (`username`, `email`, `password_hash`, `name`, `role`)
VALUES ('admin', 'admin@saatvikpharma.com', '$2y$10$w8uDk2fXjXm.n0f.4Q047.8oP3xIe6P/c9fTjFkWw3xQZp3zQ5b5S', 'Saatvik Head Pharmacist', 'superadmin')
ON DUPLICATE KEY UPDATE `email` = VALUES(`email`);

-- 2. Products Table
CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(64) PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `category` VARCHAR(100) NOT NULL,
  `short_description` TEXT,
  `description` LONGTEXT,
  `key_ingredients` TEXT,
  `dosage_instructions` TEXT,
  `benefits` TEXT,
  `rating` DECIMAL(3,2) DEFAULT 4.8,
  `reviews_count` INT DEFAULT 0,
  `featured` TINYINT(1) DEFAULT 0,
  `base_price` DECIMAL(10,2) NOT NULL,
  `base_compare_price` DECIMAL(10,2) NULL,
  `default_image_url` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Product Variations Table (Size & Pack Variations)
CREATE TABLE IF NOT EXISTS `product_variations` (
  `id` VARCHAR(64) PRIMARY KEY,
  `product_id` VARCHAR(64) NOT NULL,
  `size` VARCHAR(100) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `compare_price` DECIMAL(10,2) NULL,
  `stock` INT DEFAULT 50,
  `image_url` TEXT NOT NULL,
  `sku` VARCHAR(64) NOT NULL,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Orders Table
CREATE TABLE IF NOT EXISTS `orders` (
  `id` VARCHAR(64) PRIMARY KEY,
  `order_number` VARCHAR(50) NOT NULL UNIQUE,
  `customer_name` VARCHAR(150) NOT NULL,
  `customer_phone` VARCHAR(30) NOT NULL,
  `customer_email` VARCHAR(150),
  `address_line` TEXT NOT NULL,
  `locality` VARCHAR(150),
  `city` VARCHAR(100) NOT NULL,
  `state` VARCHAR(100) NOT NULL,
  `pincode` VARCHAR(20) NOT NULL,
  `customer_notes` TEXT,
  `subtotal` DECIMAL(10,2) NOT NULL,
  `discount` DECIMAL(10,2) DEFAULT 0.00,
  `shipping_fee` DECIMAL(10,2) DEFAULT 0.00,
  `total_amount` DECIMAL(10,2) NOT NULL,
  `payment_method` ENUM('COD', 'UPI', 'CARD', 'NETBANKING') NOT NULL,
  `payment_status` ENUM('Pending', 'Paid', 'Failed') DEFAULT 'Pending',
  `order_status` ENUM('Pending', 'Confirmed', 'Processing', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled') DEFAULT 'Pending',
  `tracking_number` VARCHAR(100) NULL,
  `estimated_delivery` VARCHAR(100) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Order Items Table
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` VARCHAR(64) NOT NULL,
  `product_id` VARCHAR(64) NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `variation_id` VARCHAR(64) NOT NULL,
  `variation_size` VARCHAR(100),
  `unit_price` DECIMAL(10,2) NOT NULL,
  `quantity` INT NOT NULL,
  `item_total` DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Third-Party API Integrations Table (Admin Only)
CREATE TABLE IF NOT EXISTS `api_integrations` (
  `id` VARCHAR(64) PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `provider` VARCHAR(120) NOT NULL,
  `category` ENUM('Payment Gateway', 'Shipping & Courier', 'SMS & WhatsApp', 'ERP & Inventory', 'Analytics & Custom') NOT NULL,
  `base_url` VARCHAR(500) NOT NULL,
  `auth_type` ENUM('bearer', 'api_key_header', 'basic_auth') DEFAULT 'bearer',
  `header_name` VARCHAR(120) DEFAULT 'Authorization',
  `api_key` TEXT NOT NULL,
  `api_secret` TEXT NULL,
  `webhook_url` VARCHAR(500) NULL,
  `environment` ENUM('sandbox', 'live') DEFAULT 'sandbox',
  `enabled` TINYINT(1) DEFAULT 0,
  `notes` TEXT NULL,
  `last_tested_at` TIMESTAMP NULL,
  `last_test_status` ENUM('success', 'failed') NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Storefront Inbound API Keys Table (Admin Only)
CREATE TABLE IF NOT EXISTS `store_api_keys` (
  `id` VARCHAR(64) PRIMARY KEY,
  `label` VARCHAR(150) NOT NULL,
  `key_prefix` VARCHAR(32) NOT NULL,
  `key_hash` VARCHAR(255) NOT NULL UNIQUE,
  `scopes` VARCHAR(255) NOT NULL,
  `environment` ENUM('sandbox', 'live') DEFAULT 'live',
  `active` TINYINT(1) DEFAULT 1,
  `last_used_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================================
-- SEED DATA: INITIAL PRODUCTS & PACK VARIATIONS
-- ========================================================
INSERT INTO `products` (`id`, `name`, `slug`, `category`, `short_description`, `description`, `key_ingredients`, `dosage_instructions`, `benefits`, `rating`, `reviews_count`, `featured`, `base_price`, `base_compare_price`, `default_image_url`)
VALUES
('sp-001', 'Saatvik Organic KSM-66 Ashwagandha Gold', 'saatvik-organic-ashwagandha-gold', 'Ayurvedic & Herbal', 'Clinically tested root extract with 5% withanolides for deep stress relief, energy vitality & peaceful sleep.', 'Saatvik Organic Ashwagandha features premium KSM-66 full-spectrum root extract, cultivated using ancient Vedic practices and certified organic farming.', 'Organic KSM-66 Ashwagandha Root Extract (500mg)|Piperine Bio-Enhancer (5mg)|Vedic Plant Cellulose Capsule', 'Take 1 to 2 capsules twice daily with warm milk or water after meals.', 'Helps reduce stress and anxiety levels|Supports restorative REM sleep cycles|Enhances physical endurance', 4.9, 342, 1, 599.00, 799.00, '/src/assets/images/product_ashwagandha_gold_1794289670838.jpg'),
('sp-002', 'Saatvik Triple Strength Pure Omega-3 Fish Oil', 'saatvik-triple-strength-omega-3', 'Vitamins & Supplements', 'Ultra-purified molecularly distilled EPA 430mg & DHA 320mg softgels for heart, brain & joint flexibility.', 'Extracted from wild cold-water deep ocean anchovies, Saatvik Omega-3 undergoes molecular distillation to remove heavy metals and mercury.', 'Purified Deep Ocean Fish Oil (1200mg)|EPA 430mg|DHA 320mg|Natural Lemon Zest Oil', 'Take 1 softgel twice daily with food.', 'Maintains healthy cholesterol balance|Supports cognitive acuity and memory|Relieves morning joint stiffness', 4.8, 286, 1, 749.00, 999.00, '/src/assets/images/product_vitamin_omega3_1794289671639.jpg'),
('sp-003', 'Saatvik Himalayan Shilajit Resin Gold Grade', 'saatvik-himalayan-shilajit-resin', 'Ayurvedic & Herbal', 'Pure Himalayan rock exudate purified with Triphala decoction with >75% fulvic acid & 84+ ionic minerals.', 'Harvested by hand from pristine Himalayan altitudes above 18,000 feet, this Grade-A Shilajit resin is purified using traditional Ayurvedic Shodhana.', 'Purified Himalayan Shilajit Rock Exudate (>75% Fulvic Acid)|Gold Bhasma trace bio-actives', 'Dissolve pea-sized ball (300-500mg) in warm milk, green tea, or lukewarm water once daily.', 'Natural cellular ATP energy booster|Promotes stamina, vitality and vigor|Rich in 84+ essential bio-available trace minerals', 4.95, 412, 1, 999.00, 1499.00, '/src/assets/images/product_shilajit_resin_1794289672627.jpg'),
('sp-004', 'Saatvik Tulsi & Ginger Cough & Immunity Kadha Syrup', 'saatvik-tulsi-ginger-kadha-syrup', 'Daily Wellness', 'Sugar-free Ayurvedic throat soothing syrup enriched with 16 sacred herbs for fast cough relief & bronchial defense.', 'Saatvik Tulsi & Ginger Kadha Syrup combines sacred Krishna Tulsi, Sunthi (dry ginger), Mulethi (licorice), and Kantakari.', 'Rama & Krishna Tulsi Extract|Sunthi (Zingiber officinale)|Mulethi (Licorice Root)|Vasaka Leaf Extract', 'Adults: 2 teaspoons (10ml) 2-3 times daily. Children: 1 teaspoon (5ml) twice daily.', 'Non-drowsy bronchial & throat soothing formula|Eases dry and congested productive coughs', 4.7, 198, 1, 249.00, 320.00, '/src/assets/images/product_cough_syrup_1794289673432.jpg'),
('sp-005', 'Saatvik Kumkumadi Tailam Radiant Facial Oil', 'saatvik-kumkumadi-tailam-oil', 'Skin & Haircare', 'Authentic 26-herb Ayurvedic beauty elixir with Kashmiri saffron & sandalwood for luminous, blemish-free skin.', 'Formulated according to ancient classical text Ashtanga Hrudaya, this luxurious face oil is infused with certified Kashmiri Mogra saffron stigma.', 'Pure Kashmiri Mogra Saffron (Crocus sativus)|Red Sandalwood (Rakta Chandana)|Manjistha Root', 'Cleanse face thoroughly. Dispense 3-4 drops onto palms, gently press into damp face and neck at night.', 'Imparts a natural radiant golden glow|Helps fade hyperpigmentation, blemishes and dark spots', 4.85, 175, 1, 849.00, 1199.00, '/src/assets/images/product_skincare_oil_1794289674347.jpg'),
('sp-006', 'Saatvik Ortho-Shield Ayurvedic Joint Pain Relief Roll-On & Oil', 'saatvik-ortho-shield-pain-relief', 'Pain Relief', 'Fast-penetrating warm herbal liniment with Mahanarayan Tailam, Gandhapura & Camphor for arthritis & muscle soreness.', 'Specially crafted for senior citizens, athletes, and desk workers suffering from stiff knees, lower back tension, or frozen shoulders.', 'Mahanarayan Tailam (Classical 52-herb formulation)|Gandhapura Oil (Wintergreen / Natural Methyl Salicylate)|Eucalyptus Oil', 'Apply directly to affected painful joint or muscle area using the mess-free roller ball 2-3 times daily.', 'Deep thermal penetration relieves pain within 15 minutes|Eases chronic knee, joint, neck and back pain', 4.75, 230, 1, 399.00, 550.00, '/src/assets/images/product_pain_relief_1794289675239.jpg')
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

INSERT INTO `product_variations` (`id`, `product_id`, `size`, `price`, `compare_price`, `stock`, `image_url`, `sku`)
VALUES
('var-ash-01', 'sp-001', '60 Veggie Capsules', 599.00, 799.00, 45, '/src/assets/images/product_ashwagandha_gold_1794289670838.jpg', 'SP-ASH-60'),
('var-ash-02', 'sp-001', '120 Veggie Capsules (Value Pack)', 999.00, 1499.00, 28, '/src/assets/images/product_ashwagandha_gold_1794289670838.jpg', 'SP-ASH-120'),
('var-ash-03', 'sp-001', '180 Veggie Capsules (Family Pack)', 1399.00, 1999.00, 14, '/src/assets/images/product_ashwagandha_gold_1794289670838.jpg', 'SP-ASH-180'),
('var-omg-01', 'sp-002', '60 Enteric Softgels', 749.00, 999.00, 32, '/src/assets/images/product_vitamin_omega3_1794289671639.jpg', 'SP-OMG-60'),
('var-omg-02', 'sp-002', '120 Enteric Softgels', 1299.00, 1799.00, 19, '/src/assets/images/product_vitamin_omega3_1794289671639.jpg', 'SP-OMG-120'),
('var-omg-03', 'sp-002', '180 Softgels (Mega Pack)', 1799.00, 2499.00, 8, '/src/assets/images/product_vitamin_omega3_1794289671639.jpg', 'SP-OMG-180'),
('var-shl-01', 'sp-003', '20g Pure Resin Jar', 999.00, 1499.00, 50, '/src/assets/images/product_shilajit_resin_1794289672627.jpg', 'SP-SHL-20G'),
('var-shl-02', 'sp-003', '50g Pure Resin Jar (Bestseller)', 1899.00, 2799.00, 25, '/src/assets/images/product_shilajit_resin_1794289672627.jpg', 'SP-SHL-50G'),
('var-srp-01', 'sp-004', '100ml Bottle', 249.00, 320.00, 60, '/src/assets/images/product_cough_syrup_1794289673432.jpg', 'SP-KDH-100'),
('var-srp-02', 'sp-004', '200ml Family Value Bottle', 399.00, 550.00, 42, '/src/assets/images/product_cough_syrup_1794289673432.jpg', 'SP-KDH-200'),
('var-kum-01', 'sp-005', '15ml Dropper Bottle', 849.00, 1199.00, 30, '/src/assets/images/product_skincare_oil_1794289674347.jpg', 'SP-KUM-15'),
('var-kum-02', 'sp-005', '30ml Luxury Dropper Bottle', 1499.00, 2199.00, 16, '/src/assets/images/product_skincare_oil_1794289674347.jpg', 'SP-KUM-30'),
('var-ort-01', 'sp-006', '50ml Easy-Glide Roll-On', 399.00, 550.00, 40, '/src/assets/images/product_pain_relief_1794289675239.jpg', 'SP-ORT-50'),
('var-ort-02', 'sp-006', '100ml Massage Liniment Bottle', 649.00, 899.00, 22, '/src/assets/images/product_pain_relief_1794289675239.jpg', 'SP-ORT-100')
ON DUPLICATE KEY UPDATE `price` = VALUES(`price`);

SET FOREIGN_KEY_CHECKS = 1;
