<?php
/**
 * =====================================================================
 * Saatvik Pharma - cPanel MySQL Database & Site Configuration
 * Place this file inside your cPanel: public_html/api/config.php
 * =====================================================================
 * ONLY EDIT THE DATABASE SETTINGS BELOW WITH YOUR CPANEL MYSQL DETAILS:
 */

// Production Error Reporting (Set to 0 on live store)
error_reporting(0);
ini_set('display_errors', '0');

// =====================================================================
// 1. YOUR CPANEL DATABASE CREDENTIALS (CHANGE THESE 4 VALUES)
// =====================================================================
define('DB_HOST', 'localhost');                  // Usually 'localhost' in cPanel
define('DB_NAME', 'yourcpanel_saatvikpharma');   // e.g. user_saatvik
define('DB_USER', 'yourcpanel_dbuser');          // e.g. user_dbadmin
define('DB_PASS', 'YOUR_STRONG_PASSWORD_HERE');  // Database user password
define('DB_CHARSET', 'utf8mb4');

// =====================================================================
// 2. STORE CONFIGURATION
// =====================================================================
define('SITE_NAME', 'Saatvik Pharma');
define('SITE_URL', 'https://yourdomain.com');    // Replace with your live domain
define('CURRENCY_SYMBOL', '₹');
define('FREE_SHIPPING_THRESHOLD', 499);
define('ADMIN_SECRET_KEY', 'saatvik_jwt_salt_' . hash('sha256', DB_NAME . '2026'));

// CORS Headers for API calls
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

/**
 * Returns a shared PDO MySQL Database Connection
 */
function getDbConnection() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'Database connection failed. Please verify credentials in config.php.',
                'details' => $e->getMessage()
            ]);
            exit();
        }
    }
    return $pdo;
}

function getJsonInput() {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?: [];
}
