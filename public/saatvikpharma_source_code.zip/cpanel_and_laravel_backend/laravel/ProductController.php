<?php
namespace AppHttpControllers;

use IlluminateHttpRequest;
use IlluminateSupportFacadesDB;
use IlluminateSupportStr;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $query = DB::table('products');
        if ($request->has('category') && $request->category !== 'All') {
            $query->where('category', $request->category);
        }
        $products = $query->orderBy('featured', 'desc')->get();

        $variations = DB::table('product_variations')->get()->groupBy('product_id');

        $formatted = $products->map(function ($p) use ($variations) {
            return [
                'id' => $p->id,
                'name' => $p->name,
                'slug' => $p->slug,
                'category' => $p->category,
                'shortDescription' => $p->short_description,
                'description' => $p->description,
                'keyIngredients' => $p->key_ingredients ? explode('|', $p->key_ingredients) : [],
                'dosageInstructions' => $p->dosage_instructions,
                'benefits' => $p->benefits ? explode('|', $p->benefits) : [],
                'rating' => (float)$p->rating,
                'reviewsCount' => (int)$p->reviews_count,
                'featured' => (bool)$p->featured,
                'basePrice' => (float)$p->base_price,
                'baseComparePrice' => $p->base_compare_price ? (float)$p->base_compare_price : null,
                'defaultImageUrl' => $p->default_image_url,
                'galleryImages' => [$p->default_image_url],
                'variations' => isset($variations[$p->id]) ? $variations[$p->id]->map(function ($v) {
                    return [
                        'id' => $v->id,
                        'size' => $v->size,
                        'price' => (float)$v->price,
                        'comparePrice' => $v->compare_price ? (float)$v->compare_price : null,
                        'stock' => (int)$v->stock,
                        'imageUrl' => $v->image_url,
                        'sku' => $v->sku
                    ];
                }) : []
            ];
        });

        return response()->json(['success' => true, 'products' => $formatted]);
    }
}
