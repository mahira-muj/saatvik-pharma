<?php
namespace AppHttpControllers;

use IlluminateHttpRequest;
use IlluminateSupportFacadesDB;
use IlluminateSupportStr;

class OrderController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer.fullName' => 'required|string',
            'customer.phone' => 'required|string',
            'customer.addressLine' => 'required|string',
            'customer.city' => 'required|string',
            'customer.state' => 'required|string',
            'customer.pinCode' => 'required|string',
            'items' => 'required|array',
            'subtotal' => 'required|numeric',
            'totalAmount' => 'required|numeric',
            'paymentMethod' => 'required|string'
        ]);

        $orderId = 'ord_' . bin2hex(random_bytes(6));
        $orderNumber = 'SP-' . rand(100000, 999999);
        $c = $request->input('customer');

        DB::beginTransaction();
        try {
            DB::table('orders')->insert([
                'id' => $orderId,
                'order_number' => $orderNumber,
                'customer_name' => $c['fullName'],
                'customer_phone' => $c['phone'],
                'customer_email' => $c['email'] ?? null,
                'address_line' => $c['addressLine'],
                'locality' => $c['locality'] ?? null,
                'city' => $c['city'],
                'state' => $c['state'],
                'pincode' => $c['pinCode'],
                'customer_notes' => $c['notes'] ?? null,
                'subtotal' => $request->subtotal,
                'discount' => $request->discount ?? 0,
                'shipping_fee' => $request->shippingFee ?? 0,
                'total_amount' => $request->totalAmount,
                'payment_method' => $request->paymentMethod,
                'payment_status' => 'Pending',
                'order_status' => 'Confirmed'
            ]);

            foreach ($request->items as $it) {
                DB::table('order_items')->insert([
                    'order_id' => $orderId,
                    'product_id' => $it['productId'],
                    'product_name' => $it['productName'],
                    'variation_id' => $it['selectedVariation']['id'],
                    'variation_size' => $it['selectedVariation']['size'],
                    'unit_price' => $it['unitPrice'],
                    'quantity' => $it['quantity'],
                    'item_total' => $it['unitPrice'] * $it['quantity']
                ]);

                DB::table('product_variations')
                    ->where('id', $it['selectedVariation']['id'])
                    ->decrement('stock', $it['quantity']);
            }

            DB::commit();
            return response()->json([
                'success' => true,
                'orderId' => $orderId,
                'orderNumber' => $orderNumber,
                'message' => 'Order created successfully'
            ]);
        } catch (Exception $e) {
            DB::rollBack();
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
