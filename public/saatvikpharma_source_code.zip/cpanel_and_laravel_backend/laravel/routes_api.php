<?php
/**
 * Laravel routes/api.php
 * Routes for Saatvik Pharma Laravel Backend
 */
use IlluminateSupportFacadesRoute;
use AppHttpControllersProductController;
use AppHttpControllersOrderController;
use AppHttpControllersAdminAuthController;

// Public E-Commerce Storefront Routes
Route::prefix('v1')->group(function () {
    Route::get('/products', [ProductController::class, 'index']);
    Route::get('/products/{id}', [ProductController::class, 'show']);
    Route::post('/orders', [OrderController::class, 'store']);
    Route::get('/orders/track/{orderNumber}', [OrderController::class, 'track']);

    // Admin Authentication & Management Routes (Protected)
    Route::post('/admin/login', [AdminAuthController::class, 'login']);
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/admin/orders', [OrderController::class, 'adminOrders']);
        Route::patch('/admin/orders/{id}/status', [OrderController::class, 'updateStatus']);
        Route::post('/admin/products', [ProductController::class, 'storeOrUpdate']);
        Route::delete('/admin/products/{id}', [ProductController::class, 'destroy']);
    });
});
