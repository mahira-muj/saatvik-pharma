<?php
/**
 * =====================================================================
 * Saatvik Pharma - Lightweight, Self-Contained PHP REST API
 * Place this file inside your cPanel: public_html/api/api.php
 * Runs on ANY standard cPanel shared hosting (Apache/LiteSpeed + PHP 7.4/8.x)
 * without requiring Composer, Node.js or SSH access!
 * =====================================================================
 */
require_once __DIR__ . '/config.php';

$pdo = getDbConnection();
$action = isset($_GET['action']) ? trim($_GET['action']) : '';
$requestMethod = $_SERVER['REQUEST_METHOD'];

/**
 * Validate optional X-API-Key header for external ERP / mobile integrations.
 */
function verifyStoreApiKey($pdo, $requiredScope = null) {
    $providedKey = $_SERVER['HTTP_X_API_KEY'] ?? '';
    if (empty($providedKey)) {
        return false;
    }
    $hash = hash('sha256', $providedKey);
    $stmt = $pdo->prepare("SELECT * FROM store_api_keys WHERE key_hash = ? AND active = 1 LIMIT 1");
    $stmt->execute([$hash]);
    $record = $stmt->fetch();
    if (!$record) {
        return false;
    }
    if ($requiredScope !== null) {
        $scopes = array_map('trim', explode(',', $record['scopes']));
        if (!in_array($requiredScope, $scopes, true)) {
            return false;
        }
    }
    $upd = $pdo->prepare("UPDATE store_api_keys SET last_used_at = NOW() WHERE id = ?");
    $upd->execute([$record['id']]);
    return true;
}

// ---------------------------------------------------------------------
// 1. PUBLIC: GET ALL PRODUCTS WITH PACK VARIATIONS
// ---------------------------------------------------------------------
if ($action === 'get_products' && $requestMethod === 'GET') {
    $category = isset($_GET['category']) ? trim($_GET['category']) : '';
    
    if ($category && $category !== 'All') {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE category = ? ORDER BY featured DESC, created_at DESC");
        $stmt->execute([$category]);
    } else {
        $stmt = $pdo->query("SELECT * FROM products ORDER BY featured DESC, created_at DESC");
    }
    $products = $stmt->fetchAll();

    $varStmt = $pdo->query("SELECT * FROM product_variations ORDER BY price ASC");
    $allVariations = $varStmt->fetchAll();

    $varMap = [];
    foreach ($allVariations as $v) {
        $varMap[$v['product_id']][] = [
            'id' => $v['id'],
            'size' => $v['size'],
            'price' => (float)$v['price'],
            'comparePrice' => $v['compare_price'] ? (float)$v['compare_price'] : null,
            'stock' => (int)$v['stock'],
            'imageUrl' => $v['image_url'],
            'sku' => $v['sku']
        ];
    }

    $formatted = [];
    foreach ($products as $p) {
        $formatted[] = [
            'id' => $p['id'],
            'name' => $p['name'],
            'slug' => $p['slug'],
            'category' => $p['category'],
            'shortDescription' => $p['short_description'],
            'description' => $p['description'],
            'keyIngredients' => $p['key_ingredients'] ? explode('|', $p['key_ingredients']) : [],
            'dosageInstructions' => $p['dosage_instructions'],
            'benefits' => $p['benefits'] ? explode('|', $p['benefits']) : [],
            'rating' => (float)$p['rating'],
            'reviewsCount' => (int)$p['reviews_count'],
            'featured' => (bool)$p['featured'],
            'basePrice' => (float)$p['base_price'],
            'baseComparePrice' => $p['base_compare_price'] ? (float)$p['base_compare_price'] : null,
            'defaultImageUrl' => $p['default_image_url'],
            'galleryImages' => [$p['default_image_url']],
            'variations' => isset($varMap[$p['id']]) ? $varMap[$p['id']] : []
        ];
    }

    echo json_encode(['success' => true, 'products' => $formatted]);
    exit();
}

// ---------------------------------------------------------------------
// 2. PUBLIC: CREATE ORDER
// ---------------------------------------------------------------------
if ($action === 'create_order' && $requestMethod === 'POST') {
    $data = getJsonInput();
    if (empty($data['customer']) || empty($data['items'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Incomplete order payload']);
        exit();
    }

    $orderId = 'ord_' . bin2hex(random_bytes(6));
    $orderNumber = 'SP-' . rand(100000, 999999);
    $c = $data['customer'];

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("INSERT INTO orders 
            (id, order_number, customer_name, customer_phone, customer_email, address_line, locality, city, state, pincode, customer_notes, subtotal, discount, shipping_fee, total_amount, payment_method, payment_status, order_status, estimated_delivery)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', 'Confirmed', '3-5 Business Days')");
        
        $stmt->execute([
            $orderId,
            $orderNumber,
            $c['fullName'],
            $c['phone'],
            $c['email'] ?? '',
            $c['addressLine'],
            $c['locality'] ?? '',
            $c['city'],
            $c['state'],
            $c['pinCode'],
            $c['notes'] ?? '',
            $data['subtotal'],
            $data['discount'] ?? 0,
            $data['shippingFee'] ?? 0,
            $data['totalAmount'],
            $data['paymentMethod']
        ]);

        $itemStmt = $pdo->prepare("INSERT INTO order_items 
            (order_id, product_id, product_name, variation_id, variation_size, unit_price, quantity, item_total)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        $stockStmt = $pdo->prepare("UPDATE product_variations SET stock = GREATEST(0, stock - ?) WHERE id = ?");

        foreach ($data['items'] as $it) {
            $itemStmt->execute([
                $orderId,
                $it['productId'],
                $it['productName'],
                $it['selectedVariation']['id'],
                $it['selectedVariation']['size'],
                $it['unitPrice'],
                $it['quantity'],
                $it['unitPrice'] * $it['quantity']
            ]);
            $stockStmt->execute([$it['quantity'], $it['selectedVariation']['id']]);
        }

        $pdo->commit();
        echo json_encode([
            'success' => true,
            'orderId' => $orderId,
            'orderNumber' => $orderNumber,
            'message' => 'Order placed successfully'
        ]);
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['error' => 'Order placement failed: ' . $e->getMessage()]);
        exit();
    }
}

// ---------------------------------------------------------------------
// 3. PUBLIC: TRACK ORDER BY ORDER NUMBER
// ---------------------------------------------------------------------
if ($action === 'track_order' && $requestMethod === 'GET') {
    $num = trim($_GET['order_number'] ?? '');
    if (!$num) {
        http_response_code(400);
        echo json_encode(['error' => 'Order number is required']);
        exit();
    }

    $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_number = ? LIMIT 1");
    $stmt->execute([$num]);
    $order = $stmt->fetch();

    if (!$order) {
        http_response_code(404);
        echo json_encode(['error' => 'Order not found']);
        exit();
    }

    $itemStmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $itemStmt->execute([$order['id']]);
    $order['items'] = $itemStmt->fetchAll();

    echo json_encode(['success' => true, 'order' => $order]);
    exit();
}

// ---------------------------------------------------------------------
// 4. PRIVATE ADMIN: LOGIN (SECURE BCRYPT VERIFICATION)
// ---------------------------------------------------------------------
if ($action === 'admin_login' && $requestMethod === 'POST') {
    $data = getJsonInput();
    $usernameOrEmail = trim($data['username'] ?? '');
    $password = $data['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ? OR email = ? LIMIT 1");
    $stmt->execute([$usernameOrEmail, $usernameOrEmail]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password_hash'])) {
        $token = bin2hex(random_bytes(32));
        $updateStmt = $pdo->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?");
        $updateStmt->execute([$admin['id']]);

        echo json_encode([
            'success' => true,
            'token' => $token,
            'admin' => [
                'name' => $admin['name'],
                'email' => $admin['email'],
                'role' => $admin['role']
            ]
        ]);
        exit();
    }

    http_response_code(401);
    echo json_encode(['error' => 'Invalid administrator credentials']);
    exit();
}

// ---------------------------------------------------------------------
// 5. PRIVATE ADMIN: GET ORDERS
// ---------------------------------------------------------------------
if ($action === 'admin_orders' && $requestMethod === 'GET') {
    $orders = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC")->fetchAll();
    foreach ($orders as &$ord) {
        $itemStmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $itemStmt->execute([$ord['id']]);
        $ord['items'] = $itemStmt->fetchAll();
    }
    echo json_encode(['success' => true, 'orders' => $orders]);
    exit();
}

// ---------------------------------------------------------------------
// 6. PRIVATE ADMIN: UPDATE ORDER STATUS
// ---------------------------------------------------------------------
if ($action === 'admin_update_order' && $requestMethod === 'POST') {
    $data = getJsonInput();
    $orderId = $data['orderId'] ?? '';
    $status = $data['status'] ?? '';
    $tracking = $data['trackingNumber'] ?? null;

    if (!$orderId || !$status) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing parameters']);
        exit();
    }

    $stmt = $pdo->prepare("UPDATE orders SET order_status = ?, tracking_number = COALESCE(?, tracking_number) WHERE id = ?");
    $stmt->execute([$status, $tracking, $orderId]);

    echo json_encode(['success' => true, 'message' => 'Order status updated']);
    exit();
}

// ---------------------------------------------------------------------
// 7. PRIVATE ADMIN: SAVE / UPDATE PRODUCT
// ---------------------------------------------------------------------
if ($action === 'admin_save_product' && $requestMethod === 'POST') {
    $p = getJsonInput();
    if (empty($p['name']) || empty($p['basePrice'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid product payload']);
        exit();
    }

    $id = !empty($p['id']) ? $p['id'] : 'sp_' . bin2hex(random_bytes(4));
    $slug = !empty($p['slug']) ? $p['slug'] : strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $p['name'])));

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("INSERT INTO products 
            (id, name, slug, category, short_description, description, key_ingredients, dosage_instructions, benefits, base_price, default_image_url)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
            name = VALUES(name), category = VALUES(category), short_description = VALUES(short_description),
            description = VALUES(description), base_price = VALUES(base_price), default_image_url = VALUES(default_image_url)");

        $stmt->execute([
            $id,
            $p['name'],
            $slug,
            $p['category'] ?? 'Ayurvedic & Herbal',
            $p['shortDescription'] ?? '',
            $p['description'] ?? '',
            is_array($p['keyIngredients']) ? implode('|', $p['keyIngredients']) : ($p['keyIngredients'] ?? ''),
            $p['dosageInstructions'] ?? '',
            is_array($p['benefits']) ? implode('|', $p['benefits']) : ($p['benefits'] ?? ''),
            $p['basePrice'],
            $p['defaultImageUrl'] ?? ''
        ]);

        if (!empty($p['variations']) && is_array($p['variations'])) {
            $delStmt = $pdo->prepare("DELETE FROM product_variations WHERE product_id = ?");
            $delStmt->execute([$id]);

            $vStmt = $pdo->prepare("INSERT INTO product_variations (id, product_id, size, price, compare_price, stock, image_url, sku) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            foreach ($p['variations'] as $v) {
                $vid = !empty($v['id']) ? $v['id'] : 'var_' . bin2hex(random_bytes(4));
                $vStmt->execute([
                    $vid,
                    $id,
                    $v['size'],
                    $v['price'],
                    $v['comparePrice'] ?? null,
                    $v['stock'] ?? 50,
                    $v['imageUrl'] ?? $p['defaultImageUrl'],
                    $v['sku'] ?? ('SP-' . strtoupper(substr($slug, 0, 4)))
                ]);
            }
        }

        $pdo->commit();
        echo json_encode(['success' => true, 'productId' => $id, 'message' => 'Product saved successfully']);
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
        exit();
    }
}

// ---------------------------------------------------------------------
// 8. PRIVATE ADMIN: API INTEGRATIONS CRUD (PAYMENT, COURIER, SMS, ERP)
// ---------------------------------------------------------------------
if ($action === 'admin_get_integrations' && $requestMethod === 'GET') {
    $stmt = $pdo->query("SELECT * FROM api_integrations ORDER BY updated_at DESC");
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
    exit();
}

if ($action === 'admin_save_integration' && $requestMethod === 'POST') {
    $in = getJsonInput();
    if (empty($in['name']) || empty($in['baseUrl'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Integration name and baseUrl are required']);
        exit();
    }
    $id = !empty($in['id']) ? $in['id'] : 'int_' . bin2hex(random_bytes(4));
    $stmt = $pdo->prepare("INSERT INTO api_integrations
        (id, name, provider, category, base_url, auth_type, header_name, api_key, api_secret, webhook_url, environment, enabled, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        name = VALUES(name), provider = VALUES(provider), category = VALUES(category),
        base_url = VALUES(base_url), auth_type = VALUES(auth_type), header_name = VALUES(header_name),
        api_key = VALUES(api_key), api_secret = VALUES(api_secret), webhook_url = VALUES(webhook_url),
        environment = VALUES(environment), enabled = VALUES(enabled), notes = VALUES(notes)");
    $stmt->execute([
        $id,
        $in['name'],
        $in['provider'] ?? $in['name'],
        $in['category'] ?? 'Analytics & Custom',
        $in['baseUrl'],
        $in['authType'] ?? 'bearer',
        $in['headerName'] ?? 'Authorization',
        $in['apiKey'] ?? '',
        $in['apiSecret'] ?? null,
        $in['webhookUrl'] ?? null,
        $in['environment'] ?? 'sandbox',
        !empty($in['enabled']) ? 1 : 0,
        $in['notes'] ?? null
    ]);
    echo json_encode(['success' => true, 'id' => $id, 'message' => 'API integration saved']);
    exit();
}

if ($action === 'admin_delete_integration' && $requestMethod === 'POST') {
    $in = getJsonInput();
    $id = $in['id'] ?? '';
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'Integration ID is required']);
        exit();
    }
    $stmt = $pdo->prepare("DELETE FROM api_integrations WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(['success' => true, 'message' => 'API integration deleted']);
    exit();
}

// ---------------------------------------------------------------------
// 9. PRIVATE ADMIN: STOREFRONT API KEYS (X-API-Key AUTH FOR EXTERNAL APPS)
// ---------------------------------------------------------------------
if ($action === 'admin_create_api_key' && $requestMethod === 'POST') {
    $in = getJsonInput();
    $label = trim($in['label'] ?? '');
    $env = ($in['environment'] ?? 'live') === 'sandbox' ? 'sandbox' : 'live';
    $scopes = is_array($in['scopes'] ?? null) ? implode(',', $in['scopes']) : 'products:read';
    if (!$label) {
        http_response_code(400);
        echo json_encode(['error' => 'API key label is required']);
        exit();
    }
    $rawKey = 'sp_' . $env . '_' . bin2hex(random_bytes(24));
    $id = 'key_' . bin2hex(random_bytes(4));
    $stmt = $pdo->prepare("INSERT INTO store_api_keys (id, label, key_prefix, key_hash, scopes, environment, active) VALUES (?, ?, ?, ?, ?, ?, 1)");
    $stmt->execute([$id, $label, substr($rawKey, 0, 14), hash('sha256', $rawKey), $scopes, $env]);
    echo json_encode(['success' => true, 'id' => $id, 'apiKey' => $rawKey, 'message' => 'API key generated']);
    exit();
}

// ---------------------------------------------------------------------
// Default fallback
// ---------------------------------------------------------------------
echo json_encode([
    'service' => 'Saatvik Pharma API',
    'status' => 'online',
    'timestamp' => date('Y-m-d H:i:s'),
    'currency' => 'INR (₹)'
]);
