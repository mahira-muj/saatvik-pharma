=====================================================================
SAATVIK PHARMA - CPANEL SHARED HOSTING DEPLOYMENT GUIDE
=====================================================================

This bundle is specially configured for standard cPanel shared hosting
(Apache/LiteSpeed + PHP 7.4/8.x + MySQL/MariaDB).

STEP 1: UPLOAD FRONTEND AND HTACCESS
1. In cPanel, open "File Manager" and navigate to "public_html" (or your subdomain directory).
2. Upload the built static files (from your dist/ folder or the extracted zip root):
   - index.html
   - assets/ (contains all optimized CSS, JS & images)
   - .htaccess
   - favicon & icons

STEP 2: CREATE MYSQL DATABASE IN CPANEL
1. In cPanel, click "MySQL Databases".
2. Create a new database (e.g. youruser_saatvik).
3. Create a new user (e.g. youruser_dbadmin) with a strong password.
4. Under "Add User To Database", select the user and database, click "Add", and check "ALL PRIVILEGES".

STEP 3: IMPORT DATABASE SCHEMA & SEED DATA
1. In cPanel, open "phpMyAdmin".
2. Select your newly created database on the left sidebar.
3. Click the "Import" tab at the top.
4. Click "Choose File" and select "saatvikpharma_schema.sql" from this package.
5. Click "Go". This creates all tables and pre-populates all 6 products, size variations, and the default admin account.

STEP 4: CONFIGURE DATABASE CREDENTIALS IN config.php
1. Inside cPanel File Manager, create a folder named "api" inside "public_html":
   public_html/api/
2. Upload "config.php" and "api.php" into "public_html/api/".
3. Right-click "config.php" and choose "Edit":
   Change:
     define('DB_HOST', 'localhost');
     define('DB_NAME', 'youruser_saatvik');
     define('DB_USER', 'youruser_dbadmin');
     define('DB_PASS', 'YOUR_STRONG_PASSWORD');
     define('SITE_URL', 'https://yourdomain.com');
4. Save changes.

STEP 5: ACCESS THE PRIVATE ADMIN PANEL
- Storefront URL: https://yourdomain.com
- Dedicated Private Admin URL: https://yourdomain.com/admin  (or https://yourdomain.com/#admin)
- Default Admin Email: admin@saatvikpharma.com
- Default Admin Password: Saatvik@Admin2026!

All prices are in Indian Rupees (₹).
Zero admin links appear on the public storefront.
=====================================================================
